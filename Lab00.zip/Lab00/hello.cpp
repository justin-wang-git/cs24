#include <iostream>

using namespace std;

int main()
{
    cout << "Hello, world!" << endl;
    cout << "I am ready for CS24!" << endl;
    return 0;
}