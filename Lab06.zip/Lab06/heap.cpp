// heap.cpp
// Justin Wang

#include "heap.h"
#include <iostream>
#include <vector>
using std::cout;

// Pushes a value into the heap, then ensures
// the heap is correctly arranged
void Heap::push(int value)
{
  vdata.push_back(value);
  
  int minindex;
  // sort(vdata.begin(), vdata.end());
  
  for (int i = 0; i < vdata.size(); i++)
  {
    minindex = i;
    for (int j = i + 1; j < vdata.size(); j++)
    {
      if (vdata.at(j) < vdata.at(minindex))
      {
        minindex = j;
      }
    }
    int temp = vdata.at(minindex);
    vdata.at(minindex) = vdata.at(i);
    vdata.at(i) = temp;
  }
}

// Pops the minimum value off the heap
// (but does not return it), then ensures
// the heap is correctly arranged
void Heap::pop()
{
  vdata.erase(vdata.begin());

  int minindex;
  for (int i = 0; i < vdata.size(); i++)
  {
    minindex = i;
    for (int j = i + 1; j < vdata.size(); j++)
    {
      if (vdata.at(j) < vdata.at(minindex))
      {
        minindex = j;
      }
    }
    int temp = vdata.at(minindex);
    vdata.at(minindex) = vdata.at(i);
    vdata.at(i) = temp;
  }
}

// Returns the minimum element in the heap
int Heap::top()
{
  return vdata.at(0);
}

// Returns true if the heap is empty, false otherwise
bool Heap::empty()
{
  if (vdata.size() == 0)
  {
    return true;
  }
  else
  {
    return false; 
  }  
}
    
