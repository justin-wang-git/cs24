#include "intbst.h"
#include <math.h>
#include <iostream>
#include <string.h>
#include <string>


using namespace std;

bool compareStrings(string s1, string s2) {
   int compare = s1.compare(s2);
   if (compare != 0)
      return false;
   else if(compare == 0)
      return true;
}

int main()
{
    IntBST bst1;
    vector<int> elements2;

    //insert data into bst1
    bst1.insert(29);
    bst1.insert(109);
    bst1.insert(12);
    bst1.insert(32);
    bst1.insert(11);
    bst1.insert(4);
    bst1.insert(1);
    bst1.insert(2586);


    //Test preorder
        cout << "pre-order: " << endl;
        cout << "expected: 29 109 12 32 11 4 1 2586" << endl;
        cout << "actual: ";
        bst1.printPreOrder();
        cout << endl;
    

    //Test inorderarray
        cout << "inorderarray" << endl;
        cout << "expected: 1 4 11 12 29 32 109 2586" << endl;
        cout << "actual: ";
        bst1.printArray(elements2);
        cout << endl;
        
    //Test printinorder
        cout << "in-order: " << endl;
        cout << "expected: 1 4 11 12 32 109 2586 29" << endl;
        cout << "actual: ";
        bst1.printPostOrder();
        cout << endl;

    
    
    //Test printpostorder
        cout << "post-order: ";
        cout << "expected: 1 4 11 12 29 32 109 2586" << endl;
        cout << "actual: ";
        bst1.printInOrder();
        cout << endl;


    //Test sum
    int total = 2784;
    int bst1sum = bst1.sum();
    if (total == bst1sum)
    {
        cout << "  sum: " << bst1.sum() << endl;
    }
    else
    {
        cout << "expected: 2784" << endl;
        cout << "actual: " << bst1.sum() << endl;
    }
    

    //Test count
    int count = 8;
    int bst1count = bst1.count();
    if (count == bst1count)
    {
        cout << "  count: " << bst1.count() << endl;
    }
    else
    {
        cout << "expected: 8" << endl;
        cout << "actual: " << bst1.count() << endl;
    }
    

    //Test contains
    cout << "  contains 29? " << (bst1.contains(29) ? "Y" : "N") << endl;
    cout << "  contains 4? " << (bst1.contains(4) ? "Y" : "N") << endl;
    cout << "  contains 12? " << (bst1.contains(12) ? "Y" : "N") << endl;
    cout << "  contains 2586? " << (bst1.contains(2586) ? "Y" : "N") << endl;
    cout << "  contains 17? " << (bst1.contains(17) ? "Y" : "N") << endl;
    cout << "  contains 1? " << (bst1.contains(1) ? "Y" : "N") << endl; 

    cout << "  predecessor of 29 is: " << bst1.getPredecessor(29) << endl;
    cout << "  predecessor of 109 is: " << bst1.getPredecessor(109) << endl;
    cout << "  predecessor of 12 is: " << bst1.getPredecessor(12) << endl;
    cout << "  successor of 32 is: " << bst1.getSuccessor(32) << endl;
    cout << "  successor of 11 is: " << bst1.getSuccessor(11) << endl;
    cout << "  successor of 4 is: " << bst1.getSuccessor(4) << endl;   
}