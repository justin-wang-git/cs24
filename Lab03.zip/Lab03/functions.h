// functions.h - Interface for the functions module

#ifndef FUNCTIONS_H
#define FUNCTIONS_H

void sayHello();
void printDate();

#endif
