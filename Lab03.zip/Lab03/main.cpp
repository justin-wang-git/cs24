#include <iostream>
#include "functions.h"
using namespace std;

int main()
{
  sayHello();
  printDate();
  cout << "Bye Bye!" << endl;
  return 0;
}
