// movies.h
// Justin Wang
// 5/25/20

#ifndef MOVIES_H
#define MOVIES_H
#include <vector>
#include <iostream>
#include <string>
using namespace std;

class BST 
{
public:
    // constructor done
    BST();
    // destructor done
    ~BST(); 

    // insert done
    bool insert(string name, double rating); 
    // print preorder done
    void printPreOrder() const; 
    // find best rated movie
    void best(string prefix) const;
    // time to search movies 
    void search(string movie, int W) const;
    
    
    
private:

    struct Node 
    {
      string moviename;
      double movierating;
      Node *left, *right, *parent;
      
      Node(string v = " ", double r = 0.0) : movierating(r), moviename(v), left(NULL), right(NULL), parent(NULL){}
    };

    Node *root; 
    
    int getDepth(Node *n) const; 
    Node* getNodeFor(string name, Node *n) const; 
    //create vector of movies with a certain prefix done
    void findMovies(string prefix, vector<Node*> &movielist) const; 

    // helper functions done
    void clear(Node *n); 
    bool insert(string name, double rating, Node *n); 
    void printPreOrder(Node *n) const; 
    void findMovies(string prefix, vector<Node*> &movielist, Node *n) const; 
};

#endif