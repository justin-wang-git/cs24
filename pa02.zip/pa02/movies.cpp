// movies.cpp
// Justin Wang
// 5/25/20

#include "movies.h"
#include "utility.h"
#include <iostream>
#include <string>
#include <ctime>
#include <vector>


using namespace std;

// constructor sets up empty tree
BST::BST() : root(0) {}

// destructor deletes all nodes
BST::~BST()
{
    clear(root);
}

// recursive clear helper
void BST::clear(Node *n)
{
    if (n)
    {
        clear(n->left);
        clear(n->right);
        delete n;
    }
}

// insert function
bool BST::insert(string name, double rating)
{
    if (!root)
    {
        root = new Node(name, rating);
        return true;
    }
    return insert(name, rating, root);
}

// recursive insert help
bool BST::insert(string name, double rating, Node *n)
{
    int N_visited = 0;
    int N = 0;
    string mName = n->moviename;
    if(mName.compare(name) > 0) 
    {
        if(n->left)
        {
            return insert(name, rating, n->left);
        }
        else 
        {
            n->left = new Node(name, rating);
            n->left->parent = n;
            N_visited += 1;
            N += 1;
            return true;
        }
    }
    else 
    if(mName.compare(name) < 0) 
    {
        if(n->right)
        {
            return insert(name, rating, n->right);
        }
        else 
        {
            n->right = new Node(name, rating);
            n->right->parent = n;
            N_visited += 1;
            N += 1;
            return true;
	    }
    }
    else
    {
        return false;
    }
}

// preorder function
void BST::printPreOrder() const
{
    printPreOrder(root);
}

// preorder helper
void BST::printPreOrder(Node *n) const
{
    if (n)
    {
        // << n->moviename << ", " << n->movierating << ", "
        cout  << getDepth(n) <<endl;
        printPreOrder(n->left);
        printPreOrder(n->right);
    }
}

// gets depth of a node
int BST::getDepth(Node *n) const {
    int i = 0;
    Node *counter= n;

    while(counter->parent) 
    {
        i++;
        counter = counter->parent;
    }
    return i;
}

BST::Node* BST::getNodeFor(string name, Node *n) const {
    Node* temp = n;
    while (temp)
    {
        if (temp->moviename == name)
        {
            return temp;
        }
        else
        {
            if (name.compare(temp->moviename) > 0)
            {
                temp = temp->right;
            }
            else
            {
                temp = temp->left;
            }
        }
    } 
    return temp;
}

void BST::findMovies(string prefix, vector<Node*> &movielist) const 
{
    findMovies(prefix, movielist, root);
}

void BST::findMovies(string prefix, vector<Node*> &movielist, Node* n) const {
    int prefixlength = prefix.size();
    Node* temp = n;
    if (temp)
    {
        if (prefix.compare(temp->moviename.substr(0, prefixlength)) == 0)
        {
            movielist.push_back(temp);
        }
        findMovies(prefix, movielist, n->left);
        findMovies(prefix, movielist, n->right);
    }
}

void BST::best(string prefix) const
{
    vector<Node*> movies;
    findMovies(prefix, movies);
    Node* bestMovie = 0;
    
    if (!movies.empty())
    {
        bestMovie = movies[0];

        for (int i = 0; i < movies.size(); i++)
        {
            if (movies[i]->movierating > bestMovie->movierating)
            {
                bestMovie = movies[i];
            }
        }
        cout << "Best movie is " << bestMovie->moviename << " with rating " << bestMovie->movierating << endl;
    }
}

void BST::search(string movie, int W) const
{
    clock_t t;
    Node* temp = 0;
    t = clock();
    double sum = 0;
    double avg = 0;
    double min = 0;
    double max = 0;
    double timer = 0;
    for (int i = 0; i < W; i++)
    {
        temp = getNodeFor(movie, root);
        t = clock() - t;
        timer = t;
        sum += t;
        // cout << "Time it took to search node: " << (float)t/CLOCKS_PER_SEC << endl;
        temp = 0; 
        if (t > timer)
        {
            min = timer;
            timer = 0;
        }
        else
        {
            max = timer;
            timer = 0;
        }
        t = clock();
    }

    avg = sum / W;

    cout << "Minimum Time: " << min << " ms" << endl;
    cout << "Average Time: " << avg << " ms" << endl;
    cout << "Maximum Time: " << max << " ms" << endl;
}

