// utility.cpp
// Justin Wang
// 5/25/20

#include <iostream>
#include "utility.h"
#include "movies.h"

using namespace std;