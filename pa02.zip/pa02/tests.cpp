// tests.cpp
// Justin Wang 
// 5/25/20

#include "tests.h"
#include "movies.h"
#include <iostream>

using namespace std;

int getTest();

// creates two trees (one of which is empty),
// and does some simple tests of tree methods
int main()
{

    BST bst1;

    // insert data to bst1
    bst1.insert("star wars: the phantom menace", 1.0);
    bst1.insert("star wars: the clone wars", 2.0);
    bst1.insert("star wars: revenge of the sith", 3.0);
    bst1.insert("star wars: a new hope", 4.0);
    bst1.insert("star wars: the empire strikes back", 5.0);
    bst1.insert("star wars: return of the jedi", 6.0);
    bst1.insert("star wars: the force awakens", 7.0);

    // let user choose one or all tests
    bool all = true;
    int testnum = getTest();
    if (testnum)
        all = false;

    if (all || testnum == 1)
    {
        cout << "  pre-order: " << endl;
        bst1.printPreOrder();
        cout << endl;
    }
    if (all || testnum == 2)
    {
        cout << "  best: " << endl;
        bst1.best("the");
        cout << endl;        
    }
    return 0;
}

int getTest()
{
    cout << "Choice of tests:\n"
         << "  0. all tests\n"
         << "  1. just printPreOrder\n"
         << "  2. just best\n";

    do
    {
        int choice;
        cout << "Enter choice:\n";
        cin >> choice;
        if (choice >= 0 && choice <= 7)
            return choice;
        cout << "0, 1, or 2 only!\n";
    } while (true);
}