// usestack.cpp - for CS 24 lab practice using stacks
// Justin Wang 5/18/20

#include "intstack.h"
#include "math.h"
#include <iostream>
using namespace std;

int main() {
    // evaluating 7 4 68 14 + * + sqrt 

    Stack numbers;

    // first three tokens all numbers to push "7 4 68 14":
    numbers.push(7);
    numbers.push(4);
    numbers.push(68);
    numbers.push(14);

    // calculation to do "+":
    int right = numbers.top();
    numbers.pop();
    int left = numbers.top();
    numbers.pop();
    numbers.push(left + right);

    // calculation "*":
    right = numbers.top();
    numbers.pop();
    left = numbers.top();
    numbers.pop();
    numbers.push(left * right);

    // calculation "+":
    right = numbers.top();
    numbers.pop();
    left = numbers.top();
    numbers.pop();
    numbers.push(left + right);

    // calculation sqrt:
    int last = numbers.top();
    numbers.pop();
    numbers.push(sqrt(last));

    // done - print result:
    cout << numbers.top() << endl;

    return 0;
}
