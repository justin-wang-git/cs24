// intlist.cpp
// Implements class IntList
// Justin Wang
// 6949184
// 4/15/20

#include "intlist.h"

#include <iostream>
using std::cout;

// copy constructor
IntList::IntList(const IntList& source) 
{
    first = new Node;
    Node* firstnode = source.first;
    first->info = firstnode->info;
    first->next = 0;
    firstnode = firstnode->next;
    while (firstnode)
    {
        append(firstnode->info);
        firstnode = firstnode->next;
    }
}

// destructor deletes all nodes
IntList::~IntList() 
{
    Node *n = first;    
    Node *b = n;
    while(n != 0)
    {            
        b = n->next;
        delete n;
        n = b;
    }
    
}


// return sum of values in list
int IntList::sum() const {
    int sum = 0;
    Node *n = first;
    if (n == 0)
    {
        return 0;
    }
    while (n != 0)
    {
        sum += n->info;
        n = n->next;
    }
    return sum;
}

// returns true if value is in the list; false if not
bool IntList::contains(int value) const {
    Node *n = first;
        while (n != 0)
        {
            if (n->info == value)
            {
                return true;
            }
            n = n->next;
        }
        return false;
}

// returns maximum value in list, or 0 if empty list
int IntList::max() const {
    int max = 0;
    Node *n = first;
    if (n == 0)
    {
        return 0;
    }
    while (n->next != 0)
    {
        if(max < n->info)
        {
            max = n->info;
        }
        n = n->next;
        
    }
    return max;
}

// returns average (arithmetic mean) of all values, or
// 0 if list is empty
double IntList::average() const {
    double sum = 0;
    int numberOfInts = 0;
    double finalavg = 0;
    Node *n = first;
    if (n == 0)
    {
        return 0.0;
    }
    while (n != 0)
    {
        sum += n->info;
        n = n->next;
        numberOfInts++;
    }

    finalavg = sum/numberOfInts;
    return finalavg;
}

// inserts value as new node at beginning of list
void IntList::insertFirst(int value) {
    Node *n = first;
    Node *b = new Node();
    b->info = value;
    b->next = first;
    first = b;
}

//Assignment operator should copy the list from the source
//to this list, deleting/replacing any existing nodes
IntList& IntList::operator=(const IntList& source)
{
    // delete nodes
    Node *n = first;    
    Node *b = n;
    while(n != 0)
    {            
        b = n->next;
        delete n;
        n = b;
    }
    first = NULL;
    
    //copy constructor
    Node* firstnode = source.first;
    while (firstnode)
    {
        append(firstnode->info);
        firstnode = firstnode->next;
    }
    return *this;
}



// DO NOT CHANGE ANYTHING BELOW (READ IT THOUGH)

// constructor sets up empty list
IntList::IntList() : first(0) { }


// append value at end of list
void IntList::append(int value) {
    if (first == 0) { // empty list
        first = new Node;
        first->info = value;
        first->next = 0;
    }
    else {
        Node *n = first;
        while (n->next) // not last node yet
            n = n->next;
        n->next = new Node;
        n->next->info = value;
        n->next->next = 0;
    }
}

// print values enclose in [], separated by spaces
void IntList::print() const {
    Node *n = first;
    cout << '[';
    while (n) {
        cout << n->info;
        if (n->next)
            cout << " ";
        n = n->next;
    }
    cout << ']';
}

// return count of values
int IntList::count() const {
    int result = 0;
    Node *n = first;
    while (n) {
        ++result;
        n = n->next;
    }
    return result;
}
