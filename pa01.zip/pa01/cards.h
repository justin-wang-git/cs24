//cards.h
//Authors: Justin Wang, Isiah Fimbrez
//All class declarations go here

#ifndef CARDS_H
#define CARDS_H

#include <iostream>

using namespace std;

class Card
{
public:
    Card(string suit1 = " ", char value1 = ' ', Card *next1 = NULL); //constructor

    bool operator==(const Card& source); //overloaded == operator
    
    //member variables
    string suit;
    char value;
    Card *next;
private:
    
};


class Hand
{
public:
    //Functions
    Hand(string name1 = " ", Card* first1 = NULL);

    void append(string s, char v); // append value at end of list
    void print() const;     // print values separate by ' '
    bool contains(string s, char v) const;  // true if value in list
    bool removeCard(string s, char v); //removes card in a hand with given suit and value. If it exists, will delete and return true, else will return false.

    //Big Three
    ~Hand(); // destructor
    Hand(const Hand& source); //copy constructor (deep copy)
    Hand& operator=(const Hand& source); //overloaded = operator
    bool compareHands(const Hand& source1, const Hand& source2);
    string getName() const;
    void setName(string newname);

    //member variables
    string name;
	Card* first;// pointer to first node
private:
    
};


#endif
