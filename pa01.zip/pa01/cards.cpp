//cards.cpp
//Authors: Justin Wang, Isiah Fimbrez
//Implementation of the classes defined in cards.h

#include "cards.h"
#include <iostream>

using std::cout;

//HAND FUNCTIONS
Hand::Hand(string name1, Card* first1)
{
    name = name1;
    first = first1;
}

//append function
void Hand::append(string suit, char value) 
{
    if (first == 0) { // empty list
        first = new Card;
        first->value = value;
	    first->suit = suit;
        first->next = 0;
    }
    else 
    {
        Card *n = first;
        while (n->next) // not last node yet
        n = n->next;
        n->next = new Card;
        n->next->value = value;
	    n->next->suit = suit;
        n->next->next = nullptr;
    }
}

//print all Cards in a hand
void Hand::print() const
{
    Card *n = first;
    while (n) 
    {
        cout << n->suit << " " << n->value;
        if (n->next)
            cout << endl;
        n = n->next;
    }
}


//contains function
bool Hand::contains(string suit, char value) const 
{
    Card *n = first;
	while(n)
	{
		if(n->value == value && n->suit == suit)
		{return true;}
		n = n->next;
	}
	return false; 
}


//destructor
Hand::~Hand() 
{
    Card *n = first;    
    Card *b = n;
    while(n != 0)
    {            
        b = n->next;
        delete n;
        n = b;
    }
}


//copy constructor
Hand::Hand(const Hand& source)
{
    first = new Card;
    Card* firstcard = source.first;
    first->value = firstcard->value;
    first->suit = firstcard->suit;
    first->next = 0;
    firstcard = firstcard->next;
    while (firstcard)
    {
        append(firstcard->suit, firstcard->value);
        firstcard = firstcard->next;
    }
}

//overloaded = operator
Hand& Hand::operator=(const Hand& source)
{
    // delete nodes
    Card *n = first;    
    Card *b = n;
    while(n != 0)
    {            
        b = n->next;
        delete n;
        n = b;
    }
    first = NULL;
    
    //copy constructor
    Card* firstCard = source.first;

    while (firstCard)
    {
        append(firstCard->suit, firstCard->value);
        firstCard = firstCard->next;
    }
    return *this;
}

//getname function
string Hand::getName() const
{
    return this->name;
}

//setname function
void Hand::setName(string newname)
{
    this->name = newname;
}

//remove card from hand
bool Hand::removeCard(string s, char v)
{
    Card *n = first;
    Card *m = first->next;
    Card temp(s, v);
    while (m != NULL)
    {
        if (!(m->suit == temp.suit && m->value == temp.value))
        {
            n = m;
            m = m->next;
        }
        else
        {
            break;
        }
        
    }
    if (m == NULL)
    {
        return false;
    }
    else
    {
        n->next = m->next;
        delete m;
        return true;
    }
}

//CARD FUNCTIONS

/*
void Card::operator=(const Card& c)
{
    this->suit = c.suit;
    this->value = c.value;
    this->next = c.next;
}
*/

Card::Card(string suit1, char value1, Card *next1)
{
    suit = suit1;
    value = value1;
    next = next1;
}

//overloaded == operator
bool Card::operator==(const Card& source)
{
	if(this->suit == source.suit && this->value == source.value)
	{return true;}
	return false;
}