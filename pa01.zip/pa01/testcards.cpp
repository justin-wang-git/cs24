// This file should contain unit tests for all the 
// public interfaces of the classes that you implement

#include "cards.h"
#include "testcards.h"
#include <iostream>
#include <vector>

using namespace std;

int runall(){
  runAll();
  return 0;
}

void runAll(){
  test_append();
  test_equal();
  test_card();
}

void test_append()
{
  START_TEST("test_append");
  test_append_empty_list();
  test_append_single_element_list();
  END_TEST("test_append");

}

void test_equal()
{
  START_TEST("test_equal");
  test_equal_empty_list();
  //test_equal_single_element_list();
  END_TEST("test_equal");

}

void test_card()
{
  START_TEST("test_card");
  test_card_operator_double_equal();
  
  test_hand_card_remove();
  
  //test_equal_single_element_list();
  END_TEST("test_card");
}

void test_append_empty_list()
{ 
  Hand hand1;
  hand1.append("h", '2');

  cout << "  contains Hearts 2? " << (hand1.contains("h", '2') ? "Y" : "N") << endl;

  Hand hand2;
  hand2.append("d", 'k');
  
  cout << "  contains Diamond King? " << (hand2.contains("d", 'k') ? "Y" : "N") << endl;

  Hand hand3;
  hand2.append("s", '5');

  cout << "  contains Spades 5? " << (hand3.contains("c", '6') ? "Y" : "N") << endl;
}

void test_append_single_element_list()
{ 
  Hand hand1;
  hand1.append("h", '2');
  hand1.append("h", '3');

  cout << "  contains Hearts 3? " << (hand1.contains("h", '3') ? "Y" : "N") << endl;

  Hand hand2;
  hand2.append("d", 'k');
  hand2.append("c", '6');
  
  cout << "  contains Clubs 6? " << (hand2.contains("c", '6') ? "Y" : "N") << endl;

  Hand hand3;
  hand3.append("s", '5');
  hand3.append("d", 'j');

  cout << "  contains Diamond Jack? " << (hand3.contains("d", 'j') ? "Y" : "N") << endl;
}

void test_equal_empty_list()
{ 
  string testname = "case 0: [], []";
  Hand l1 (" ", NULL);
  Hand l2 (" ", NULL);
  bool truefalse = true;
  while (l1.first && l2.first)
  {
    if (!(l1.first == l2.first))
    {
      truefalse = false;
    }
    l1.first = l1.first->next;
    l2.first = l2.first->next;
  } 
  
  if(truefalse)
  {
    cout << "PASSED: " << testname << endl;
  }
  else
  {
    cout << "FAILED: " << testname << endl;
    cout << "Expected: "<< "true" << endl;
    cout << "Actual: " << "false" << endl;
  }
  

}

void test_card_operator_double_equal()
{
  Card card1("s", '5', NULL);
  Card card2("s", '5', NULL);
  string testdescrip = "Testing overloaded == operator: ";
  cout << testdescrip << endl;
  assertEquals(card1, card2, testdescrip);
}


void test_hand_card_remove()
{
  Hand hand1;
  hand1.append("s", '6');
  hand1.append("s", '7');
  hand1.append("s", '8');
  hand1.append("s", '9');
  cout << "Testing remove card: " << endl;
  if (hand1.removeCard("s", '7') == true)
  {
    cout << "PASSED" << endl;
  }
  else
  {
    cout << "FAILED" << endl;
    cout << "Expected: true  Actual: " << hand1.removeCard("s", '7') << endl;
  }
}


int main()
{
  runAll();
  return 0;
}




