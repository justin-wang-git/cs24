#include <iostream>
#include <fstream>
#include <string>
#include "cards.h"
using namespace std;

int main(int argv, char** argc){
  if(argv != 3){
    cout << "Please provide 2 file names" << endl;
    return 1;
  }


  ifstream cardFile1 (argc[1]);
  ifstream cardFile2 (argc[2]);
  string line;

  if (cardFile1.fail()){
    cout << "Could not open file " << argc[1];
    return 1;
  }

  if (cardFile2.fail()){
    cout << "Could not open file " << argc[2];
    return 1;
  }

  // Create two objects of the class you defined 
  // to contain two sets of cards in two input files

  Hand Bob;
  Bob.setName("Bob");
  Hand Alice;
  Alice.setName("Alice");
  // Read each file and store cards
  while(!cardFile1.eof())
  {
	  char v;
	  string s;
	  cardFile1 >> s >> v;
	  Alice.append(s,v);
  }
  
  cardFile1.close();
  Alice.removeCard("", 'a');

  while(!cardFile2.eof())
  {
	  char v;
	  string s;
	  cardFile2 >> s >> v;
	  Bob.append(s,v);
  }
  cardFile2.close();
  Bob.removeCard("", '3');
  
  // Start the game
  Card *bob = Bob.first;
  Card *alice = Alice.first;
  int i = 1;

  while (bob && alice)
  {
    Card *bobnext = bob->next;
    Card *alicenext = alice->next;
    if (i%2 != 0)
    {
      if(Bob.contains(alice->suit, alice->value)) //case for alice and she goes first
      {
        cout << "Alice picked matching card " << alice->suit << " "<< alice->value << endl;
        Bob.removeCard(alice->suit, alice->value);
        Alice.removeCard(alice->suit, alice->value);
        alice = alicenext;
      }
      else
      if(!(Bob.contains(alice->suit, alice->value)))
      {
        alice = alicenext;
      }
      
    }

    if (i%2 == 0)
    {
      if (Alice.contains(bob->suit, bob->value)) //case for bob
      {
        cout << "Bob picked matching card " << bob->suit << " "<< bob->value << endl;
        Alice.removeCard(bob->suit, bob->value);
        Bob.removeCard(bob->suit, bob->value);
        bob = bobnext;
      }
      else
      if(!(Alice.contains(alice->suit, alice->value)))
      {
        bob = bobnext;
      }
    }
    i += 1;
  }

//printing out the remaining cards;

  cout << "Alice's cards:" << endl;
  Alice.print();
  cout << endl;

  cout << "Bob's cards:" << endl;
  Bob.print();
  cout << endl;

  return 0;
}
